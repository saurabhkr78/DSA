/******************************************************************************

                              Online C++ Debugger.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Debug" button to debug it.

*******************************************************************************/

#include <iostream>
#include <vector>
using namespace std;
int main()
{
    int arr[]={0,1,2,3,4,5,6,7,8,9};
    int n=10;
    vector<int>v(10);
    for(int i=0;i<n;i++){
        v[i]=arr[i];
        cout<<v[i]<<" ";
    }
       sort(v);
       
       
       int n=0;
 for(int i=0;i<n;i++){
        n*=10;
        n+=arr[i];
        cout<<n;
      }
    

    return 0;
}

