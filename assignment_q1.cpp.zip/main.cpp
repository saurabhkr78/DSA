/******************************************************************************

                              Online C++ Debugger.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Debug" button to debug it.

*******************************************************************************/

#include <iostream>
#include<string>
using namespace std;

int main()
{
    string s;
    cin>>s;
    
 for(int i=1;i<(int)s.size();i+=2){
     s[i]='#';
 }
 cout<<s;

    return 0;
}
