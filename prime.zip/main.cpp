// prime no-divisible by 1 and number itself
// 2i sthe smallest even prime number
/* composite number -which is not prime number having more than 2 factors */
//composite number having even number of factors except perfect square and exist in pair
//perfect squares having odd number of factors 
// if any number has factors except 1 and n then half of the factprs will lie before sqrt(n)
/*if i is factor of n then n/i is also a factor.
if n is divisible by i then i is factor of n */

#include<iostream>
#include <math.h>
using namespace std;

// bool isPrime(int n)
// {
//  if(n==1) return false;
//  for(int i=2;i<n-1;i++){
//      if(n%2==0) return false;
//  }
//  return true;

// }
int fact = 0;
bool
isPrime (int n)
{
  if (n == 1)
	return false;
  for (int i = 2; i < sqrt (n); i++)
	{
	  if (n % i == 0)
		{
		  fact = i;
		  return false;
		}
	}
  return true;

}

int
main ()
{
  int n;
  cout << "enter number: ";
  cin >> n;
  cout << isPrime (n) << endl;
  cout << fact;
  return 0;
}
