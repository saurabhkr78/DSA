// Write a function which accepts a 2D array of integers and its size as arguments and displays the 
// elements of middle row and the elements of middle column.
// [Assuming the 2D Array to be a square matrix with odd dimensions i.e. 3x3, 5x5, 7x7 etc...

#include <iostream>
#include<climits>
using namespace std;

int main()
{
    
    int m,n;
    cout<<"enter rows:column"<<endl;
    cin>>m>>n;
    
    int a[m][n];
    
    cout<<"Enter matrix elements"<<endl;
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cin>>a[i][j];
        }
    }
    
    //matix elements are 

    cout<<"Elements are"<<endl;
      for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cout<<a[i][j];
        }
        cout<<endl;
    }
    //logic
  for(int i=0;i<m;i++){
      for(int j=0;j<n;j++){
          if(i==m/2 || j==n/2){
              cout<<a[i][j]<<" ";
          }
          else cout<<" "<<" ";
      }
      cout<<endl;
  }

    return 0;
}




