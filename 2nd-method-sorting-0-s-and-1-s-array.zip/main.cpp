/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.
  
// sort array of 1s and 0's 2nd method  
*******************************************************************************/
#include <iostream>
#include<vector>
using namespace std;

void sort(vector <int>&v){
   
   int i=0;
   int j=v.size()-1;
   
   while(i<j)
   {
       if(v[i]==1&&v[j]==0){
           v[i]=0;
           v[j]=1;
           i++;
           j--;
       }
       
       if(v[i]==0)
           i++;
       if(v[j]==1)
           j--;
       //3rdmethod:if(i>j) break;
       //4th method:condition with else if
       //5th method:take && loop above if(v[i]==0)
       
       
   }
}
   
int main()
{
    vector<int> v;
    
    v.push_back(1);
    v.push_back(1);
    v.push_back(0);
    v.push_back(1);
    v.push_back(0);
    v.push_back(1);
    v.push_back(1);
    v.push_back(0);
    v.push_back(1);
   for(int i=0;i<v.size();i++){
       cout<<v[i];
       
   }
   cout<<endl;
   sort(v);
   for(int i=0;i<v.size();i++){
      cout<<v[i]; 
   }
   
    return 0;
}
