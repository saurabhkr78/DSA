/*
Given a sorted binary array, efficiently count the total number of 1’s in it.
Input 1 : a = [0,0,0,0,1,1]
Output 1: 2
*/
#include <iostream>

int main()
{
    std::cout<<"Hello World";

    return 0;
}