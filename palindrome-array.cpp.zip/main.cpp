#include <iostream>
using namespace std; 

int main() 
{
    int a[] = {1, 2, 3, 4, 3, 2, 1};
    int n = sizeof(a) / sizeof(a[0]);

    bool flag = true; // assume it's a palindrome
   int i=0;
   int j=n-1;
   while(i<j){
       if (a[i] != a[j])
        {
            flag = false;
            break;
        }
        i++;
        j--;
   }

    if (flag=true)
        cout << "Palindrome array" << endl;
    else
        cout << "Not a palindrome array" << endl;

    return 0; 
}
