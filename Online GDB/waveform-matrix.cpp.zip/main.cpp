#include <iostream>

using namespace std;

int main()
{
    
   int m,n;
   cin>>m>>n;
   int a[m][n];
   //input
   cout<<"enter elements"<<endl;
   for(int i=0;i<m;i++){
       for(int j=0;j<n;j++){
           cin>>a[i][j];
       }
   }
   //print
 cout<<"elements are"<<endl;
   for(int i=0;i<m;i++){
       for(int j=0;j<n;j++){
           cout<<a[i][j];
       }
       cout<<endl;
   }
   //column printing 
   for(int j=0;j<m;j++){
       for(int i=0;i<m;i++){
          
          cout<<a[i][j]<<" ";
       }
   }
}