/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Given a positive integer, return true if it is a power of 2.
#include<iostream>
using namespace std;

bool check(int n){
    if(n==1) return true;
    
    if(n%2==0) return check(n/2);
    
    return false;
}

int main(){
    int n;
    cin>>n;
    if(check(n)){
        cout<<"yes";
    }
    else cout<<"false";
    
   
    
    
    return 0;
}
