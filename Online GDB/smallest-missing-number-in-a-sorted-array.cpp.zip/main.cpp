/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int
main ()
{
  // //O(n) approach
  // int arr[8]={0,1,2,3,4,8,9,12};
  // int n=8;
  // for(int i=0;i<n;i++){
  //     if(i!=arr[i]){
  //     cout<<i;
  //     break;
  //     }

  // }
  
  //using binary search
  int arr[8] = { 0, 1, 2, 3, 4, 8, 9, 12 };
  int n = 8;
  int low = 0, high = n - 1;
  int ans = 0;

  while (low <= high)
	{
	  int mid = low + (high - low) / 2;
	  if (arr[mid] == mid)
		{
		  low = mid + 1;

		}
	  else
		{
		  ans = mid;
		  high = mid - 1;
		}
	}
  cout << ans;
  return 0;
}
