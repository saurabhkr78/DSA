/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

//Write a program to calculate the sum of odd numbers between a and b (both inclusive) using
recursion.
*******************************************************************************/

#include <iostream>
using namespace std;

int sumOdd(int a, int b) {
    // Base condition
    if(a > b) return 0;
    
    // Sum condition
    if(a % 2 != 0) return a + sumOdd(a + 1, b);
    
    // If 'a' is even, skip it
    return sumOdd(a + 1, b);
}

int main() {
    int a, b;
    cin >> a >> b;
    cout << sumOdd(a, b);
    return 0;
}
