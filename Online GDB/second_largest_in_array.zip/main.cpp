/******************************************************************************
Find the second largest element in the given Array in one pass.
*******************************************************************************/
#include <iostream>
#include<climits>
using namespace std;
   
int main()
{
   int n;
   cout<<"Size:";
   cin>>n;
   
   int a[n];
   cout<<"elemtents:";
   
   for(int i=0;i<=n-1;i++)
   {
       cin>>a[i];
   }
  
      int max=INT_MIN;
    for(int i=0;i<=n-1;i++) 
    {
      if( max<a[i])
        max=a[i];
        
    }
    
     int secondmax=INT_MIN ;
    for(int i=0;i<=n-1;i++) 
    {
      if( a[i]!=max && secondmax<a[i])
        secondmax=a[i];
    
    }
    cout<<endl;
    cout<<max<<endl;
    cout<<secondmax<<endl;

    return 0;
}


