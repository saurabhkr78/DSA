#include <iostream>
using namespace std;

int main()
{
    int arr[9]={1,2,4,6,14,18,23,29,34};
    int n=9;
    int x=12;
    
    int low=0;
    int high=n-1;
    bool flag=false;
    while(low<=high){
        int mid=low+(high-low)/2;
        /*for upper bound
        int mid=low+(high-low)/2;*/
        if(arr[mid]==x){
            flag=true;  //what if element is present in array so a flag is required to check it;
            cout<<arr[mid-1];//to produce lower bound of x
            break;
        } 
        else if (arr[mid]<x)  low=mid+1;
        else high=mid-1;
        
    }
    if(!flag)
    cout<<arr[high]<<endl;
    /*for upper bound of x
     cout<<arr[low];
     */

    return 0;
}
