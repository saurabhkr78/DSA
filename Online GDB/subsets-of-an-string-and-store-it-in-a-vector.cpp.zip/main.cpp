/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<string>
#include<vector>
using namespace std;

void printSubstring(string str,string s,vector<string>&v){
    if(str.length()==0){
        v.push_back(s);
        return;
    }
    char ch=str[0];
    
    printSubstring(str.substr(1),s,v);
    printSubstring(str.substr(1),s+ch,v);
    
}


int main()
{
    string str;
    cout<<"enter a String";
    cin>>str;
    string s;
    
    vector<string>v;
    printSubstring(str,s,v);
    
    for(string i:v){
        cout<<i<<endl;
    }
    return 0;
}
