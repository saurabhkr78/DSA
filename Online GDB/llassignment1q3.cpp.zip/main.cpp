/*Implement a Linked List class.
The user defined LL should have insert (head,tail,idx) , delete(head,tail,idx) , get(idx) and display
functions.*/
#include <iostream>
using namespace std;

class node {
public:
    int val;
    node* next;

    node(int n) {
        val = n;
        next = NULL;
    }
};

class linkedlist {
public:
    node* head, *tail;
    int size;

    linkedlist() {
        head = tail = NULL;
        size = 0;
    }

    void display() {
        node* temp = head;
        while (temp != NULL) {
            cout << temp->val << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    void insertAtFirst(int val) {
        node* temp = new node(val);
        if (size == 0) {
            head = tail = temp;
        }
        else {
            temp->next = head;
            head = temp;
        }
        size++;
    }

    void insertAtEnd(int val) {
        node* temp = new node(val);
        if (size == 0) {
            head = tail = temp;
        }
        else {
            tail->next = temp;
            tail = temp;
        }
        size++;
    }

    void insertAtidx(int val, int idx) {
        if (idx < 0 || idx > size) {
            cout << "Invalid Index" << endl;
            return;
        }
        if (idx == 0) {
            insertAtFirst(val);
        }
        else if (idx == size) {
            insertAtEnd(val);
        }
        else {
            node* temp = new node(val);
            node* traverse = head;
            for (int i = 0; i < idx - 1; i++) {
                traverse = traverse->next;
            }
            temp->next = traverse->next;
            traverse->next = temp;
            size++;
        }
    }

    void dltAtFirst() {
        if (size == 0) {
            cout << "List is empty" << endl;
            return;
        }
        node* temp = head;
        head = head->next;
        delete temp;
        size--;
        if (size == 0) {
            tail = NULL;
        }
    }

    void dltAtEnd() {
        if (size == 0) {
            cout << "List is empty" << endl;
            return;
        }
        if (size == 1) {
            delete head;
            head = tail = NULL;
            size--;
            return;
        }
        node* temp = head;
        while (temp->next != tail) {
            temp = temp->next;
        }
        delete tail;
        tail = temp;
        tail->next = NULL;
        size--;
    }

    void dltAtidx(int idx) {
        if (idx < 0 || idx >= size) {
            cout << "Invalid Index" << endl;
            return;
        }
        if (idx == 0) {
            dltAtFirst();
            return;
        }
        if (idx == size - 1) {
            dltAtEnd();
            return;
        }
        node* temp = head;
        for (int i = 0; i < idx - 1; i++) {
            temp = temp->next;
        }
        node* toDelete = temp->next;
        temp->next = temp->next->next;
        delete toDelete;
        size--;
    }

    int getAtidx(int idx) {
        if (idx < 0 || idx >= size) {
            cout << "Invalid Index" << endl;
            return -1;
        }
        if (size == 1) {
            return head->val;
        }
        node* temp = head;
        for (int i = 0; i < idx; i++) {
            temp = temp->next;
        }
        return temp->val;
    }
};

int main() {
    linkedlist ll;

    
    ll.insertAtEnd(1);
    ll.insertAtEnd(2);
    ll.insertAtEnd(3);
    ll.insertAtFirst(0);
    ll.insertAtidx(4, 2);

    
    cout << "Initial List: ";
    ll.display(); 

    
    ll.dltAtFirst();
    ll.dltAtEnd();
    ll.dltAtidx(1);

   
    cout << "List after deletions: ";
    ll.display();

   
    cout << "Element at index : " << ll.getAtidx(1) << endl;

    return 0;
}
