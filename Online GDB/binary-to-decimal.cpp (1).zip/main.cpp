/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
// 100000111
int main()
{  
    
    int size;
    cout<<"Enter Size: "<<endl;
    cin>>size;
    int bin[size];
    cout<<"enter binary number:"<<endl;
    for(int i=0;i<size;i++){
        cin>>bin[i];
    }
    
   
    int sum=0;
    int x=1;
    
    for(int i=size-1;i>=0;i--){
        sum+=bin[i]*x;
        x*=2;
    }
    cout<<"sum:"<<sum<<endl;

    return 0;
}