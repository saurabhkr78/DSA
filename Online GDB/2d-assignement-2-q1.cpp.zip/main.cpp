/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.


Q1: Write a program to store 10 at every index of a 2D matrix with 5 rows and 5 columns.
*******************************************************************************/
#include <iostream>
#include <vector>
using namespace std;

int main()
{
   
   int m;
   cout<<"enter no of rows:";
   cin>>m;
   int n;
   cout<<"enter no of columns:";
   cin>>n;
   
  vector<vector<int>> v(m, vector<int>(n));
  for(int i=0;i<m;i++){
      for(int j=0;j<m;j++){
          cin>>v[i][j];
      }
  }
  
   for(int i=0;i<m;i++){
      for(int j=0;j<m;j++){
          
          //condition?
          v[i][j]=10;
          
          cout<<v[i][j]<<" ";
      }
      cout<<endl;
  }
   

    return 0;
}