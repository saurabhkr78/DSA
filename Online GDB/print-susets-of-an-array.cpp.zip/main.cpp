/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<string>
#include<vector>
using namespace std;

void subsets(int arr[],int size,int idx,vector<int>ans){
    if(idx==size){
        for(int i=0;i<ans.size();i++){
        cout<<ans[i]<<" ";
        
    }
        cout<<endl;
        return;
    }
    subsets(arr,size,idx+1,ans);
    ans.push_back(arr[idx]);
    subsets(arr,size,idx+1,ans);
    
}


int main()
{
  int arr[]={1,2,3};
  int size=sizeof(arr)/sizeof(arr[0]);
  int idx;  
    vector<int>ans;
    subsets(arr,size,0,ans);
    
    
    return 0;
}
