#include <iostream>

using namespace std;

int main()
{
    
   int m,n;
   cin>>m>>n;
   int a[m][n];
   //input
   cout<<"enter elements"<<endl;
   for(int i=0;i<m;i++){
       for(int j=0;j<n;j++){
           cin>>a[i][j];
       }
   }
   //print
 cout<<"elements are"<<endl;
   for(int i=0;i<m;i++){
       for(int j=0;j<n;j++){
           cout<<a[i][j];
       }
       cout<<endl;
   }
   cout<<endl;
   //transpose
   for(int i=0;i<n;i++){
       for(int j=0;j<m;j++){
        int temp=a[i][j];
        a[i][j]=a[j][i];
        a[j][i]=temp;
       
       cout<<a[i][j]<<" ";
       }
       cout<<endl;
       //rotating 90 degree anti clockwise
     //outer loop  column traversal
       for(int k=0;k<n;k++){
           // reversing row using two var
           int i=0;
           int j=m-1;
           while(i<j){
           int temp=a[i][k];
            int a[j][k]=a[i][k];
            int a[i][k]=temp;
           i++;
           j--;
          }
       }
       //print
       for(int i=0;i<m;i++){
       for(int j=0;j<n;j++){
           cout<<a[i][j];
       }
       cout<<endl;
   }
   cout<<endl;
   }
    return 0;
}
