/******************************************************************************
Find the second largest element in the given Array in one pass.
*******************************************************************************/
#include <iostream>
#include<vector>
using namespace std;
   
int main()
{
   int n;
   cout<<"Size:";
   cin>>n;
   
   int a[n];
   cout<<"elemtents:";
   
   for(int i=0;i<=n-1;i++)
   {
       cin>>a[i];
   }
  
 int max=a[0];
    for(int i=1;i<=n-1;i++)
    {
      if( max<a[i])
        max=a[i];
        cout<<endl;
    }
    cout<<max;
    

    return 0;
}

