/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// #include <iostream>
// using namespace std;
// int main()
// {
//     //first occurence
//     int a[]={0,0,0,0,1,1,1,1,1,1};
//     int n=10;
//     int l=0;
//     int h=n-1;
//     int x=1;
//     bool flag=false;
//     while(l<=h){
//         int mid=l+(h-l)/2;
//         if(a[mid]==x){
//             if(mid==0)
//             {
//                 flag=true;
//                 cout<<mid;
//                 break;
//             }
//             else if (a[mid-1]!=x){
//                 flag=true;
//                 cout<<mid;
//                 break;
//             }
//             else h=mid-1;
//         }
//         else if(mid<x) l=mid+1;
        
//         else h=mid-1;
//     }
//     if(flag==-1) cout<<-1;


//     return 0;
// }
#include <iostream>
using namespace std;
int main()
{
    //count occurrence
    int a[]={0,0,0,0,1,1,1,1,1,1};
    int n=10;
    int l=0;
    int h=n-1;
    int x=1;
    int fi=-1;
    
    while(l<=h){
        int mid=l+(h-l)/2;
        
        
        
        //logic
        if(a[mid]==x){
            if(mid==0 || a[mid-1]!=x){
                fi=mid;
                break;
            }
            else h=mid-1;
        }
        
        
        
        else if(a[mid]<x) l=mid+1;
        
        else h=mid-1;
    }
    
    
    
    if(fi==-1) cout<<0;
    else cout<<(n-fi);//(n-1-fi+1) without travesring the right space to count how many elents are there





    return 0;
}