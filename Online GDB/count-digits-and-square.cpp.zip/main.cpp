/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.


//Write a function to count the number of digits in a number and then print the square of this number.
*******************************************************************************/
#include <iostream>


using namespace std;
int square(int num)
{
    return num*num;
}

int countDigit(int n){
    int count=0;
    while(n>0){
    int Digit=n%10;
    count++;
    n/=10;
    }
    return count;
}
int main()
{
    int n;
    cin>>n;
   
   
   
   int nd=countDigit(n);
   cout<<square(nd);
    

    return 0;
}