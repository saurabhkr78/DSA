#include <iostream>
using namespace std;

// Creating a user-defined data type
class node {
public:
    int val;
    node* next;

    // Constructor
    node(int val) {
        this->val = val;
        this->next = NULL;
    }
};

// User-defined data structure
class LinkedList {
public:
    node* head;
    node* tail;
    int size;
//User-defined data structure constructor
    LinkedList() {
        head = tail = NULL;
        size = 0;
    }

    void insertAtEnd(int Val) {
        node* temp = new node(Val);
        if (size == 0) {
            head = tail = temp;
        } 
        else {
            tail->next = temp;
            tail = temp;
        }
        size++;
    }

    // Print linked list in order
    void display() {
        node* temp = head;
        if (temp == NULL) return;
        while (temp != NULL) {
            cout << temp->val << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    LinkedList ll;
    ll.insertAtEnd(10);
    ll.insertAtEnd(20);
    ll.insertAtEnd(30);
    ll.insertAtEnd(40);
    ll.insertAtEnd(50);
    ll.display();

    return 0;
}
