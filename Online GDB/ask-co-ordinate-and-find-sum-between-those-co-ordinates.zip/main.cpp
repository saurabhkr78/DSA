/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

Given a matrix ‘A’ of dimension n x m and 2 coordinates (l1, r1) and (l2, r2). Return the sum of the 
rectangle from (l1,r1) to (l2, r2)

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    
    int m,n;
    cout<<"enter rows:column"<<endl;
    cin>>m>>n;
    
    int a[m][n];
    
    cout<<"enter matrix elements";
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cin>>a[i][j];
        }
    }
    //matix elements are 
    cout<<"elements are";
     for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cout<<a[i][j];
        }
         cout<<endl;
        
        
       
    }
    
    
    
    int r1,c1;
    cout<<"enter 1st co-ordinstes"<<endl;
    cin>>r1>>c1;
    int r2,c2;
    cout<<"Enter 2nd co-ordinates"<<endl;
    cin>>r2>>c2;
    int sum=0;
    for(int i=r1;i<=r2;i++){
        for(int j=c1;j<=c2;j++){
            sum+=a[i][j];
        }
       
    }
    cout<<sum;

    return 0;
}