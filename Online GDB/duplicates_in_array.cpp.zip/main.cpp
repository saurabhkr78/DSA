//Given an array, predict if the array contains duplicates or not.

#include<iostream>
using namespace std;

int main(){
    
    int n;
    cin>>n;
    
    
    
    
    int a[n];
    for(int i=0;i<=n-1;i++){
        cin>>a[i];
    }
    int key=a[0];
    bool flag=false;
    
    for(int i=0;i<=n-1;i++){
        if(a[i]==a[i+1])
        flag=true;
       cout<<a[i];
       
    }
    cout<<endl;
   cout<<flag;
    return 0;
}