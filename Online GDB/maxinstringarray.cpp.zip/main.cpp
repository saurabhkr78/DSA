/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<string>
using namespace std;

int main()
{
    string a[]={"0123","0023","456","00182","940","002160"};
    int max=stoi(a[0]);
    string maxS=a[0];
    for(int i=1;i<=5;i++){
       int x=stoi(a[i]);
    
    if(x>max){
        max=x;
        maxS=a[i];
    }
    
}
    cout<<max<<" "<<maxS;
    return 0;
}