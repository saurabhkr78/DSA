/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<string>
using namespace std;

int main()
{
    string str="123456";
    int x=stoi(str);
    cout<<x<<endl;
    cout<<x+1<<endl;
    
    int y=123456;
    string s=to_string(y);
    cout<<str<<endl;
    
    
    string t="12345662346887798";
    long long z=stoll(t);
    cout<<z<<endl;
    cout<<z+1<<endl;
    

    return 0;
}