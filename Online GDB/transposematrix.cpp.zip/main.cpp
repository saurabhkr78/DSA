/******************************************************************************

                              Online C++ Debugger.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Debug" button to debug it.

Write a program to transpose the matrix.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    
   int m,n;
   cin>>m>>n;
   int a[m][n];
   //input
   cout<<"enter elements"<<endl;
   for(int i=0;i<m;i++){
       for(int j=0;j<n;j++){
           cin>>a[i][j];
       }
   }
   //print
 cout<<"elements are"<<endl;
   for(int i=0;i<m;i++){
       for(int j=0;j<n;j++){
           cout<<a[i][j];
       }
       cout<<endl;
   }
   cout<<endl;
   //transpose
   for(int i=0;i<n;i++){
       for(int j=0;j<m;j++){
        int temp=a[i][j];
        a[i][j]=a[j][i];
        a[j][i]=temp;
       
       cout<<a[i][j]<<" ";
       }
       cout<<endl;
       
       
       
   }
    return 0;
}

