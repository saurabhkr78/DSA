/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;


void hanoi(int disk,char A,char B,char C){
    if(disk==0) return;
    //1.step:to move n-1 disks from start rod to Destination rod using recursion 
    
    hanoi(disk-1,A,C,B);
    //2.step:direvtly move the biggest disk to destination rod from starting rod
    cout<<A<<"->"<<C<<endl;
    //3-step:now move the n-1 disk to destination which was kept on helper rod using recursion
    hanoi(disk-1,B,A,C);
   
    
    
    
}




int main()
{
    int disk;
    cin>>disk;
    hanoi(disk,'A','B','C');

    return 0;
}
