#include <iostream>
#include <vector>

using namespace std;

// Function to check if a number is prime
bool isPrime(int num)
{
    if (num < 2)
        return false;
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0)
            return false;
    }
    return true;
}

// Function to count the divisors of a number
int countDivisors(int num)
{
    int count = 0;
    for (int i = 1; i <= num; i++) {
        if (num % i == 0)
            count++;
    }
    return count;
}

// Function to count the numbers in the given range
// with even prime divisors count
long long int oddProducts(int n, vector<int> &a)
{
    long long int count = 0;
    for (int i = 0; i < n; i++) {
        int x = a[i];
        int divisors = countDivisors(x);
        if (divisors % 2 == 0 && isPrime(divisors))
            count++;
    }
    return count;
}

bool runTestCases()
{
    vector<int> arr1 = {1, 2, 4, 2};
    long long int result1 = oddProducts(arr1.size(), arr1);
    cout << "Test Case 1 Result: " << result1 << endl;
    // The divisors for the elements in arr1 are: 1(1), 2(1,2), 4(1,2,4), 2(1,2)
    // Count of even prime divisors: 1, 2, 2, 2 (total 7)

    vector<int> arr2 = {1, 2};
    long long int result2 = oddProducts(arr2.size(), arr2);
    cout << "Test Case 2 Result: " << result2 << endl;
    // The divisors for the elements in arr2 are: 1(1), 2(1,2)
    // Count of even prime divisors: 1, 2 (total 3)

    return true; // Return true if all test cases pass
}

int main()
{
    runTestCases();
    return 0;
}
