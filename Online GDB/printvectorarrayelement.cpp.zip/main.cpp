/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
#include<vector>
using namespace std;
void display(vector<int>&arr,int size,int idx){
    if(idx==size) return;
    cout<<arr[idx]<<" ";
    display(arr,size,idx+1);
}
int main()
{
  int size;
  cin>>size;
  vector<int>arr(size);
  for(int i=0;i<size;i++){
      cin>>arr[i];
  }
  display(arr,size,0);

    return 0;
}