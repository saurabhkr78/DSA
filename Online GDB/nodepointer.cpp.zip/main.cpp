#include <iostream>
using namespace std;
//creating special data type
class node{
    public:
    int val;
    node* next;
    //constructor
    node(int val){
        this->val=val;
        this->next=NULL;
    
    }
   
};
void display(node* head){
    node* temp=head;
    while(temp!=NULL){
        cout<<"Printed through display fxn:"<<temp->val<<endl;
        temp=temp->next;
    }
    cout<<endl;
}


int size(node* head){
    node* temp=head;
    int n=0;
    while(temp!=NULL){
        n++;
        temp=temp->next;
    }
    return n;
}







int main()
{
    //inserting value in node
node* a=new node(10);
node* b=new node(20);
node* c=new node(30);
node* d=new node(40);

// Connecting each node
    a->next  = b; //(*a).next = b;
    b->next = c;
    c->next = d;

    // Print the value in node b
    cout<<"The value in node b is: "<<a->next->val<<endl;
    cout << "The value in node b is: " << b->val << endl;
    cout<<"the value in node d is:"<<a->next->next->next->val<<""<<endl;
    
    //printing all the nodes value
    
    node* temp=a;// node type t=variable temp contains a address of a variable a and has access of fields of a.
    while(temp!=NULL){//till the address becomes null
        cout<<temp->val<<" ";//(*temp).val means dreferencing address stored in temp then go to their value
        temp=temp->next;
    }
    
    display(a);
    cout<<size(a);
    return 0;
}