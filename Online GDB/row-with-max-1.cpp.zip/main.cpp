#include <iostream>
using namespace std;
int main()
{
//count occurrence
int a[5][4]={{0,0,0,0},{1,0,0,0},{0,1,1,0},{1,1,1,1},{0,1,1,1}};
int m=5;
int n=4;
int row=0;
int maxOne=0;

for(int i=0;i<m;i++){//bs on every row
int countOnes=0;//no of one's in ith row
int l=0;
int h=n-1;
int x=1;
int fi=-1;

while(l<=h){
    int mid=l+(h-l)/2;
    
    
    
    //logic
    if(a[i][mid]==x){
        if(mid==0 || a[i][mid-1]!=x){
            fi=mid;
            break;
        }
        else h=mid-1;
    }
    
    
    
    else if(a[i][mid]<x) l=mid+1;
    
    else h=mid-1;
}



if(fi==-1) countOnes=0;
else countOnes=(n-fi);//(n-1-fi+1) without travesring the right space to count how many elents are there
   
if(maxOne<countOnes){
    maxOne=countOnes;
    row=i;
}
   
    
}
cout<<row<<" "<<maxOne;






return 0;
}
