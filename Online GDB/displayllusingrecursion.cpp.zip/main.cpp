#include <iostream>
using namespace std;

// Creating a special data type
class node {
public:
    int val;
    node* next;

    // Constructor
    node(int val) {
        this->val = val;
        this->next = NULL;
    }
};

// Print linked list in order
void display(node* head) {
    if (head == NULL) return;
    cout << head->val << " ";
    display(head->next);
}
// Print linked list in reverse order
void display2(node* head) {
    if (head == NULL) return;
    display2(head->next);
    cout << head->val << " ";
}
void insertAtEnd(node* head,int val) {
    node* t=new node(val);
        node* temp = head;
       while(head->next!=NULL) head=head->next;
       head->next=t;
    }

int main() {
    // Inserting values in nodes
    node* a = new node(10);
    node* b = new node(20);
    node* c = new node(30);
    node* d = new node(40);
   
    

    // Connecting each node
    (*a).next = b;
    (*b).next = c;
    (*c).next = d;

    // Display in order
    cout << "Linked list in order: ";
    display(a);
    cout << endl;

    // Display in reverse order
    cout << "Linked list in reverse order: ";
    display2(a);
    cout << endl;
    
    display(a);
    
    insertAtEnd(a,60);
    display(a);

    return 0;
}
