/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector> 

using namespace std;

int main()
{
    vector<int>v;
    
    for(int i=0;i<=5;i++){
        int x;
        cin>>x;
        v.push_back(x);
    }
   sort (v.begin(),v.end());
   for(int i=0;i<=5;i++)
    cout<<v[i];
    return 0;
}

