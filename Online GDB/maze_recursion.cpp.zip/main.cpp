#include <iostream>
using namespace std;

//upright maze
int maze(int sr,int sc,int er,int ec){
    if(sr>er || sc>ec) return 0;
    if(sr==er && sc==ec) return 1;
    int right_way=maze(sr,sc+1,er,ec);
    int down_way=maze(sr+1,sc,er,ec);
    int total_ways=right_way+down_way;
    return total_ways;
}
//reverse maze
int maze2(int r,int c){
    if(r<1 || c<1) return 0;
    if(r==1 && c==1) return 1;
    int right_way=maze2(r,c-1);
    int down_way=maze2(r-1,c);
    int total_ways=right_way+down_way;
    return total_ways;
}
//to print path
void printpath(int sr,int sc,int er,int ec,string s){
     if(sr>er || sc>ec) return ;
    if(sr==er && sc==ec){ //at destination
        cout<<s<<endl;
        return;
    }
    printpath(sr,sc+1,er,ec,s+'R');//right move
    printpath(sr+1,sc,er,ec,s+'D');//down move
}

//printpath2 using 2 parameters
void printpath2(int r,int c,string s){
     if(r<1 || c<1) return ;
    if(r==1 && c==1){ //at destination
        cout<<s<<endl;
        return;
    }
    printpath2(r,c-1,s+'R');//right move
    printpath2(r-1,c,s+'D');//down move
}

int main()
{
    cout<<maze(0,0,2,2)<<endl;
    cout<<maze2(3,3)<<endl;
    printpath(1,1,3,3,"");
    cout<<endl;
    printpath2(3,3,"");
}
