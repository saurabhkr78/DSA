

// //print all the increasing sequence of length k from array of natural number-->

// <!--//subsequence,subset,subarray-->
// <!--subsequnce-random manner combination 123,231,132,so on-->
// <!--subarray-in contineous manner like 123,234,345 -->

// <!--#A subarray is a contiguous part of array, i.e., Subarray is an array that is inside another array.-->
// <!-- for an array of size n, there are n*(n+1)/2 non-empty subarrays.-->
// <!--for array 1234- (1), (2), (3), (4), (1,2), (2,3), (3,4), (1,2,3), (2,3,4), and (1,2,3,4)-->

// <!--#A subsequence is a sequence that can be derived from another sequence by removing zero or more elements, without changing the order of the remaining elements.-->
// <!--for a sequence of size n, we can have (2n – 1) non-empty sub-sequences in total.-->
// <!--for 1234-(1), (2), (3), (4), (1,2), (1,3),(1,4), (2,3), (2,4), (3,4), (1,2,3), (1,2,4), (1,3,4), (2,3,4), (1,2,3,4).-->
// <!--#If a Set has all its elements belonging to other sets, this set will be known as a subset of the other set.-->

// <!--A Subset is denoted as “⊆“. If set A is a subset of set B, it is represented as A ⊆ B.-->

// <!--For example, Let Set_A = {m, n, o, p, q}, Set_ B = {k, l, m, n, o, p, q, r}-->



//print all the increasing sequence of length k from array of natural number











