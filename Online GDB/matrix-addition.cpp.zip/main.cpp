
#include <iostream>

using namespace std;

int main()
{
    int m,n;
    cout<<"row:";
    cin>>m;
    cout<<"column:";
    cin>>n;
    int a[m][n];
    int b[m][n];
    
    cout<<"enter elements of 1st matrix:"<<endl;
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            
            cin>>a[i][j];
        }
    }
    cout<<"enter elments of 2nd matrix:"<<endl;
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            
            cin>>b[i][j];
        }
    }
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            b[i][j]+=a[i][j];
            cout<<b[i][j]<<" ";
        }
        cout<<endl;
        
    }
    

    return 0;
}