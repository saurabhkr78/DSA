
//confusion
#include <iostream>
#include <vector>
#include <string>
using namespace std;

void storeSub(string s, string str, vector<string>& v, bool flag) {
    if (str.length() == 0) {
        v.push_back(s);
        return;
    }
    // char ch = str[0];
    // if (str.length() == 1) {
    //     if (flag == true) {
    //         storeSub(s + ch, str.substr(1), v, true);
    //         storeSub(s, str.substr(1), v, false);
    //     }
    //     else {
    //         storeSub(s + ch, str.substr(1), v, true);
    //         storeSub(s, str.substr(1), v, false);
    //     }
    //     return; // Return after handling the last character
    // }

    // char ch2 = str[1];
    // if (ch == ch2) {
    //     if (flag == true) {
    //         storeSub(s + ch, str.substr(1), v, true);
    //         storeSub(s, str.substr(1), v, false);
    //     }
    //     else {
    //         storeSub(s + ch, str.substr(1), v, true);
    //         storeSub(s, str.substr(1), v, false);
    //     }
    // }
    // else {
    //     storeSub(s + ch, str.substr(1), v, true);
    //     storeSub(s, str.substr(1), v, false);
    // }
    char ch = str[0];
    string ch2 = str.substr(1);
    storeSub(s + ch, ch2, v, true);
    if (!flag || (ch != str[1])) {
        storeSub(s, ch2, v, false);
    }
}

int main() {
    vector<string> v;
    string str = "ABC";
    string s = "";
    bool flag = true;
    storeSub(s, str, v, flag);

    for (string i : v) {
        cout << i << endl;
    }

    return 0;
}
