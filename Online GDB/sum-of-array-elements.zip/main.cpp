#include<iostream>
using namespace std;

int main() {
    int n;

    cout << "Enter size: ";
    cin >> n;

    int a[n];
    for(int i=0;i<=n;i++){
        cin>>a[i];
    }
    int product=1;
    for(int i=0;i<=n;i++){
        cout<<a[i]<<" ";
        product=product*a[i];
    }
    cout<<endl;
    cout<<"The product of array is:"<<product;
}