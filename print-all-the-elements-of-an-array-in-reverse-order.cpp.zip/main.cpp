/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

//Print all the elements of an array in reverse order.


*******************************************************************************/
#include <iostream>
#include <vector>
using namespace std;

void reverse(vector<int> &a, int CurrentIndex, int n){
    if(CurrentIndex == n) return;
    reverse(a, CurrentIndex+1, n);
    cout << a[CurrentIndex] << " ";
}

int main()
{
    int n;
    cin >> n;
    vector<int> a(n);
    for(int i = 0; i < n; i++){
        cin >> a[i];
    }
    reverse(a, 0, n);
    return 0;
}
