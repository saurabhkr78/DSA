/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.


Write a C++ program to find the largest element of a given 2D array of integers.
*******************************************************************************/
#include <iostream>
#include<climits>
using namespace std;

int main()
{
    
    int m,n;
    cout<<"enter rows:column"<<endl;
    cin>>m>>n;
    
    int a[m][n];
    
    cout<<"Enter matrix elements"<<endl;
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cin>>a[i][j];
        }
    }
    
    //matix elements are 

    cout<<"elements are"<<endl;
      for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cout<<a[i][j];
        }
        cout<<endl;
    }
    //logic
     int max=INT_MIN;
    cout<<"max element is:";
     for(int i=0;i<m;i++)
     {
        for(int j=0;j<n;j++)
        {
            if(a[i][j]>max)
            max=a[i][j];
            
        }
       
         
    }
     cout<<max;
 

    return 0;
}
