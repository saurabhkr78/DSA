// Write a program to print the row number having the maximum sum in a given matrix.

#include <iostream>
#include<climits>
using namespace std;

int main()
{
    
    int m,n;
    cout<<"enter rows:column"<<endl;
    cin>>m>>n;
    
    int a[m][n];
    
    cout<<"Enter matrix elements"<<endl;
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cin>>a[i][j];
        }
    }
    
    //matix elements are 

    cout<<"elements are"<<endl;
      for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cout<<a[i][j];
        }
        cout<<endl;
    }
    //logic
   
     int maxSum=INT_MIN;
     int row=-1;
    cout<<"max element is:";
     for(int i=0;i<m;i++)
     {
          int sum=0;
        for(int j=0;j<n;j++)
        {
          sum+=a[i][j];
            
    //     }
    //   maxSum=max(sum,maxSum);
         
    // }
        }
        if(sum>maxSum){
            maxSum=sum;
            row=i;
        }
        
        
     }
    cout<<"maxSum:"<<maxSum<<"RowNo:"<<row;

    return 0;
}



