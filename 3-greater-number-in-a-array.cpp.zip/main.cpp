

#include <iostream>
#include <vector>
#include <climits>
using namespace std;

void findMax(vector<int>&v)
{
    int n=v.size();
int mx=INT_MIN;
int smx=INT_MIN;
int tmx=INT_MIN;

 for(int i=0;i<=n;i++){
     if(v[i]>mx)
     mx=v[i];
 }
 for(int i=0;i<=n;i++){
     if(v[i]>smx&&v[i]!=mx)
     smx=v[i];
 }
 for(int i=0;i<=n;i++){
     if(v[i]>tmx&&v[i]!=mx&&v[i]!=smx)
     tmx=v[i];
 }
 
 cout<<"first max:"<<mx<<endl;
  cout<<"2nd max:"<<smx<<endl;
   cout<<"3rd max:"<<tmx<<endl;
 }
   
int main()
{
    vector<int>v(5);
    for(int i=0;i<=v.size()-1;i++){
        cin>>v[i];
    }
    cout<<endl;
    
   
    cout<<"array is:";
     for(int i=0;i<=v.size()-1;i++){
        cout<<v[i];
    }
    cout<<endl;
   
   findMax(v);
   
   

    return 0;
}