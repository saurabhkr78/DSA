/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    
    int a[n];
    for(int i=0;i<=n;i++){
        cin>>a[i];
    }
  int x;
  
  cout<<"searchable element";
  cin>>x;
  bool flag=false;
  for(int i=0;i<=n-1;i++){
      if(a[i]==x)
      flag=true;
      
  }
  if(flag==true) 
  cout<<"element found";
  else
  cout<<"Error 404!";

    return 0;
}