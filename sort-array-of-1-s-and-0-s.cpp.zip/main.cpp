/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.
  
// sort array of 1s and 0's 2nd method
*******************************************************************************/
#include <iostream>
#include<vector>
using namespace std;
void sort(vector <int>&v){
    int noon=0;
    int noze=0;
    
    for(int i=0;i<v.size();i++){
        if(v[i]==0){
            noze++;
        }
        else noon++;
    }
    for(int i=0;i<v.size();i++){
        if(i<noze)
        v[i]=0;
        else
        v[i]=1;
    }
}
int main()
{
    vector<int> v;
    
    v.push_back(1);
    v.push_back(1);
    v.push_back(0);
    v.push_back(1);
    v.push_back(0);
    v.push_back(1);
    v.push_back(0);
    v.push_back(1);
   for(int i=0;i<v.size();i++){
       cout<<v[i];
       
   }
   cout<<endl;
   sort(v);
   for(int i=0;i<v.size();i++){
      cout<<v[i]; 
   }
   
    return 0;
}
