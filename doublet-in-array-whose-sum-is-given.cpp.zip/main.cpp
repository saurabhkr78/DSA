 /******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector> 

using namespace std;

int main()
{
    
    cout<<"enter target sum";
     int t;
     cin>>t;
     
     vector<int>v;
     cout<<"Enter Size:";
     int size;
     cin>>size;
     
     cout<<"ENter Elements:";
    for(int i=0;i<=size;i++){
       
       int x;
        cin>>x;
        v.push_back(x);
    }
    
     for(int i=1;i<=v.size()-2;i++)
     {
         for(int j=i+1;j<=v.size()-1;j++)
         {
         if(v[i]+v[j]==t)
         {
             cout<<"("<<i<<","<<j<<")"<<endl;;
         }
        }
     }
}