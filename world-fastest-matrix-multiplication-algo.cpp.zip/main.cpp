#include <iostream>
#include <vector>

using namespace std;

// Utility functions for matrix operations
using Matrix = vector<vector<int>>;

Matrix add_matrices(const Matrix &A, const Matrix &B) {
    int n = A.size();
    Matrix result(n, vector<int>(n, 0));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            result[i][j] = A[i][j] + B[i][j];
        }
    }
    return result;
}

Matrix subtract_matrices(const Matrix &A, const Matrix &B) {
    int n = A.size();
    Matrix result(n, vector<int>(n, 0));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            result[i][j] = A[i][j] - B[i][j];
        }
    }
    return result;
}

Matrix strassen_multiply(const Matrix &A, const Matrix &B) {
    int n = A.size();

    // Base case: if matrices are 1x1, just return their product
    if (n == 1) {
        return {{A[0][0] * B[0][0]}};
    }

    // Split matrices into quadrants
    Matrix a11(n / 2, vector<int>(n / 2, 0)), a12(n / 2, vector<int>(n / 2, 0)),
           a21(n / 2, vector<int>(n / 2, 0)), a22(n / 2, vector<int>(n / 2, 0));
    Matrix b11(n / 2, vector<int>(n / 2, 0)), b12(n / 2, vector<int>(n / 2, 0)),
           b21(n / 2, vector<int>(n / 2, 0)), b22(n / 2, vector<int>(n / 2, 0));

    for (int i = 0; i < n / 2; ++i) {
        for (int j = 0; j < n / 2; ++j) {
            a11[i][j] = A[i][j];
            a12[i][j] = A[i][j + n / 2];
            a21[i][j] = A[i + n / 2][j];
            a22[i][j] = A[i + n / 2][j + n / 2];

            b11[i][j] = B[i][j];
            b12[i][j] = B[i][j + n / 2];
            b21[i][j] = B[i + n / 2][j];
            b22[i][j] = B[i + n / 2][j + n / 2];
        }
    }

    // Recursive steps
    Matrix p1 = strassen_multiply(a11, subtract_matrices(b12, b22));
    Matrix p2 = strassen_multiply(add_matrices(a11, a12), b22);
    Matrix p3 = strassen_multiply(add_matrices(a21, a22), b11);
    Matrix p4 = strassen_multiply(a22, subtract_matrices(b21, b11));
    Matrix p5 = strassen_multiply(add_matrices(a11, a22), add_matrices(b11, b22));
    Matrix p6 = strassen_multiply(subtract_matrices(a12, a22), add_matrices(b21, b22));
    Matrix p7 = strassen_multiply(subtract_matrices(a11, a21), add_matrices(b11, b12));

    // Compute result matrix C using intermediate results
    Matrix c11 = add_matrices(subtract_matrices(add_matrices(p5, p4), p2), p6);
    Matrix c12 = add_matrices(p1, p2);
    Matrix c21 = add_matrices(p3, p4);
    Matrix c22 = subtract_matrices(subtract_matrices(add_matrices(p5, p1), p3), p7);

    // Combine quadrants into the result matrix
    Matrix result_matrix(n, vector<int>(n, 0));
    for (int i = 0; i < n / 2; ++i) {
        for (int j = 0; j < n / 2; ++j) {
            result_matrix[i][j] = c11[i][j];
            result_matrix[i][j + n / 2] = c12[i][j];
            result_matrix[i + n / 2][j] = c21[i][j];
            result_matrix[i + n / 2][j + n / 2] = c22[i][j];
        }
    }

    return result_matrix;
}

// Function to print a matrix
void print_matrix(const Matrix &mat) {
    for (const auto &row : mat) {
        for (int val : row) {
            cout << val << " ";
        }
        cout << endl;
    }
}

int main() {
    // Example usage
    Matrix A = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};
    Matrix B = {{17, 18, 19, 20}, {21, 22, 23, 24}, {25, 26, 27, 28}, {29, 30, 31, 32}};

    // Ensure that the matrices are square and have a size that is a power of 2
    int n = A.size();
    if (n == B.size() && ((n & (n - 1)) == 0)) {
        Matrix result = strassen_multiply(A, B);

        // Print the result
        cout << "Matrix A:" << endl;
        print_matrix(A);

        cout << "\nMatrix B:" << endl;
        print_matrix(B);

        cout << "\nResultant Matrix C:" << endl;
        print_matrix(result);
    } else {
        cout << "Matrices must be square and have a size that is a power of 2." << endl;
    }

    return 0;
}
