/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

Check if the given array is almost sorted. (elements are at-most one position away)

*******************************************************************************/
#include <iostream>
using namespace std;
int
main ()
{
  int A[5] = { 7, 2, 32, 5, 20 };
  int n = 5;
  for (int i = 0; i < n - 1; i++)
	{
	  if (A[i] > A[i + 1])
		{
		  swap (A[i], A[i + 1]);
		  i++;
		}
	}
	// it stops at n - 1 is because it compares each element with its next neighbor.
  for (int i = 0; i < n - 1; i++)
  //not sorted
	if (A[i] > A[i + 1])
	  {
		cout << "Not in ascending order" << endl;
		break;
	  }
	 /*If the loop completes without finding any pair of elements where A[i] > A[i + 1], it means the array is sorted in ascending order. The code now handles this case by checking if i has reached n - 1 (the end of the array). If it has, it prints “Yes” to the console. */
  if (i == n - 1)
	cout << "Yes" << endl;
  return 0;
}
