/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<string>
using namespace std;

void printSubstring(string str,string s,int idx){
    if(idx==str.length()){
        cout<<s<<" ";
        return;
    }
    char ch=str[idx];
    
    printSubstring(str,s,idx+1);
    printSubstring(str,s+ch,idx+1);
    
}


int main()
{
    string str;
    cout<<"enter a String";
    cin>>str;
    string s;
    int idx;
    printSubstring(str,s,0);

    return 0;
}
