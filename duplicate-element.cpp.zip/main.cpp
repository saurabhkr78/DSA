/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.


// for this method array should be sorted
*******************************************************************************/
#include <iostream>
#include<algorithm>
#include<string>
using namespace std;

int main()
{
    int a[]={1,2,3,8,5,5,6,7,4};
    int sum=0;
    int n=sizeof(a)/sizeof(a[0]);
    //need to be sorted
    sort(a,a+n);
    
   for(int i=0;i<n;i++){
       sum+=a[i];
   }
  int n2=a[n-1];//Since the array is sorted, the last element is the maximum number.
   int s=n2*(n2+1)/2;
   cout<<sum-s;
    return 0;
}