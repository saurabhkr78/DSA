/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

//printing all the substrings of a strings including space

*******************************************************************************/
#include <iostream>
#include<string>
using namespace std;

void printSubstring(string str,string s){
    if(str.length()==0){
        cout<<s<<" ";
        return;
    }
    char ch=str[0];
    
    printSubstring(str.substr(1),s);
    printSubstring(str.substr(1),s+ch);
    
}


int main()
{
    string str;
    cout<<"enter a String";
    cin>>str;
    string s;
    printSubstring(str,s);

    return 0;
}