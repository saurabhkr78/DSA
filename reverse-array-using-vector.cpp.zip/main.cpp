/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>
using namespace std;
void display(vector<int> &a){
    for(int j=0;j<=a.size()-1;j++){
      cout<<a[j];
    }
}

int main()
{
    vector<int>v;
    v.push_back(3);
    v.push_back(4);
    v.push_back(5);
    v.push_back(6);
    v.push_back(7);
    v.push_back(8);
    
    display(v);
    
  vector<int>v2(v.size());
  for(int i=0;i<=v2.size();i++){
    //   i+j==sizeof()-1;
   int j=v.size()-1-i;
    v2[i]=v[j];
  }
  cout<<endl;
  
   display(v2);
    return 0;
}