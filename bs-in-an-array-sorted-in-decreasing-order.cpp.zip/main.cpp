#include<iostream>
using namespace std;
int search(int l,int h,int arr[],int t){
  while(l<=h){
      int mid=l+(h-l)/2;
      if (arr[mid]==t) return mid;
      else if (arr[mid]>t) l=mid+1;
      else h=mid-1;
  }   
  return -1;
  
}
int main(){
    int arr[]={10,9,8,7,5,3,0,-1,-4};
    int n=sizeof(arr)/4;
    int t=9;
    cout<<search(0,n-1,arr,t);
}
