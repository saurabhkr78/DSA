/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>
using namespace std;

int main()
{
    // vector<int> v(4,3);//(rows,capacity/element)
    // cout<<v[0]<<" ";
    // cout<<v[1]<<" ";
    // cout<<v[2]<<" ";
    // cout<<v[3]<<" ";
vector<vector<int> > v(3,vector<int> (4,20));// (row, size)

     cout<<v.size()<<endl;// no of rows
     cout<<v[2][2]<<endl;
     
     for(int i=0;i<3;i++){
         for(int j=0;j<4;j++){
             
             cout<<v[i][j]<<" ";
             
         }
         cout<<endl;
         
         //no of column
        
     }
     //no of column
      cout<<v[0].size()<<endl;
      //no of column
         cout<<v[1].size();
    return 0;
}