/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

given a sentence and print all the words in next line;


*******************************************************************************/
#include <iostream>
#include<string>
#include<algorithm>
#include<vector>
#include<sstream>
using namespace std;

int main()
{
    string str="my name is sky";
    stringstream ss(str);
    string temp;
    while(ss>>temp)
    cout<<temp<<endl;

    return 0;
}