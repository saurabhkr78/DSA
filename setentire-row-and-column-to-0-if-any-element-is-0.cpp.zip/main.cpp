/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

Given an m x n integer matrix , if an element is 0, set its entire row and column to 0's.
You must do it in place.
Input :
1 1 1
1 0 1
1 1 1
Output :
1 0 1
0 0 0
1 0 1








*******************************************************************************/
#include <iostream>
#include<string.h>
using namespace std;

int main ()
{
  int m;
  int n;
  cin >> m >> n;
  int a[m][n];
  for (int i = 0; i < m; i++)
    {
      for (int j = 0; j < n; j++)
	{
	  cin >> a[i][j];
	}
    }
  //logic
  // to find  r and c which is having 0;
  for (int i = 0; i < m; i++)
    {
      for (int j = 0; j < n; j++)
	{
	  if (a[i][j] == 0)
	    {
	      a[i][0] = 0;
	      a[0][j] = 0;
	    }


	}
    }
//set r and c to 0
    for (int i = 0; i < m; i++)
    {
      for (int j = 0; j < n; j++)
	{
	    if(a[i][0]==0 || a[0][j]==0)
	    {
	        a[i][j]=0;
	    }
	    cout<<a[i][j];
	}
	cout<<endl;
    }




return 0;
}

