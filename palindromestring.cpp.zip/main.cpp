#include <iostream>

using namespace std;
bool palindrome(string &str){
    int i=0;
    int j=(int)str.size()-1;
    while(i<=j){
        if(str[i]!=str[j])
            return false;
        i++;
        j--;
    }
    return true;
}

int main()
{
    int size;
    cin>>size;
    string str;
    cin>>str;
   
    cout<<(palindrome(str)?"yes":"no");
    

    return 0;
}
