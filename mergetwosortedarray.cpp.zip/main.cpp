
#include <iostream>
#include <vector>
using namespace std;

vector<int> merge(vector<int>& v1, vector<int>& v2) {
    int n = v1.size();
    int m = v2.size();

    int i = 0;
    int j = 0;
    int k = 0;

    vector<int> v3(m + n);

    while (i < n-1 && j <= m-1) {
        if (v1[i] < v2[j]) {
            v3[k] = v1[i];
            i++;
        } else {
            v3[k] = v2[j];
            j++;
        }
        k++;
    }

    while (i < n) {
        v3[k] = v1[i];
        i++;
        k++;
    }

    while (j < m) {
        v3[k] = v2[j];
        j++;
        k++;
    }

    return v3;
}

int main() {
    vector<int> a1;
    a1.push_back(1);
    a1.push_back(3);
    a1.push_back(5);
    a1.push_back(7);
    for (int i = 0; i < a1.size(); i++) {
        cout << a1[i] ;
        cout<<" ";
    }

    vector<int> a2;
    a2.push_back(2);
    a2.push_back(4);
    a2.push_back(6);
    a2.push_back(8);
    a2.push_back(10);
    a2.push_back(12);
    cout<<endl;
    for (int i = 0; i < a2.size(); i++) {
        cout << a2[i] << " ";
    
    }

    vector<int> v3 = merge(a1, a2);
    cout<<endl;
    for (int i = 0; i < v3.size(); i++) {
        cout << v3[i] << " ";
    }

    return 0;
}

