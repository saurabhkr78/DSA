/******************************************************************************
Given a sorted binary array, efficiently count the total number of 1’s in it.
Input 1 : a = [0,0,0,0,1,1]
Output 1: 2
*******************************************************************************/

#include <iostream>
using namespace std;
int main()
{  
     int a[] = {0,0,0,0,1,1};
    int n=6;
    int l=0;
    int h=n-1;
    int count=0;
    while(l<=h){
      if(arr[mid]==1){
          if(arr[n-1]!=1||arr[mid+1]!=1)
          cout<<mid;
          break;
      }
      count++;
    }
    
    

    return 0;
}
