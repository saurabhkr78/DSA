/******************************************************************************

                              Online C++ Debugger.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Debug" button to debug it.

**find frequency of char in a array**
* approach
* find length of the string
* traverse till string length
* get char ascii value 
* store in a array with 0 value if it stores a value then increase that index
* 
* find max in array
* 
* print max
* if a[i]=mx ascii value of the index
* convert ascii intto char
* 





*******************************************************************************/

#include <iostream>
#include<string>
#include<algorithm>
#include<vector>
using namespace std;

int main()
{
    string s="Saurabh";
    vector<int>a(26,0);
    // for string
    for(int i=0;i<s.size();i++){
        char ch=s[i];
        int ascii=(int)ch;
        //to store the char in array at location ascii-97 youwill get the actual location in array and ++ iis for increasing that cell value by 1 coz we are filling elements in that cell
        a[ascii-97]++;
    }
    int mx=0;
    //for array and to find ma
    for(int i=0;i<26;i++){ // now array is mapped to a-z
    if(a[i]>mx)
    mx=a[i];
   
}
//to print max
for(int i=0;i<26;i++){
    // check which element was having max freq
    if(a[i]==mx){
        // get the ascii value of index
        int ascii=i+97;
        //get that char ascii value stores
        char ch=(char)ascii;
        cout<<ch<<" "<<mx;
    }
    
}
    return 0;
}
