/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
  #include <iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    // for A
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            if(i+j==n+1)
            cout<<"*";
            else
            cout<<" ";
             }
             
      for(int j=1;j<=n+1;j++){
            if(j==i-1)
            cout<<"*";
            else
            cout<<" ";
             }  
             
        cout<<endl;
        }
        n--;
        //for V
        for(int i=1;i<=n;i++){
            cout<<" ";
        for(int j=1;j<=n;j++){
            if(j==i)
            cout<<"*";
           
            else
            cout<<" ";
             }
             
      for(int j=1;j<=n-1;j++){
            if(i+j==n)
            cout<<"*";
            else
            cout<<" ";
             }  
             
        cout<<endl;
        }
         return 0;
    } 

