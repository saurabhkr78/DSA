/******************************************************************************

 

*******************************************************************************/

#include <iostream>
using namespace std;
//creating special data type
class node{
    public:
    int val;
    node* next;
    
};

int main()
{
    //inserting values in data part
    node a;
    a.val=10;
    node b;
    b.val=20;
    node c;
    c.val=30;
    node d;
    d.val=40;
    node e;
    e.val=50;
    //linking nodes
    a.next=&b;
    b.next=&c;
    c.next=&d;
    d.next=&e;
    e.next=NULL;
    
    //to print address of any node using third variable
    node* address=&b;
    cout<<(*address).val<<endl;
    //change in b node
    (*address).val=100;//address->val
    cout<<b.val<<endl;
    //print address of any node ..
    cout<< (*(a.next)).val<<endl;//(a.next)->val
    cout<<(b.next)->val<<endl;
    //access all the node using a node
    cout<<(a.next)->next->next->next->val<<endl;
    
    //here temp is a node
    //giving accesss of entire node in a temp node and then access each node and their value
    node temp=a;
    cout<<"working in temp"<<endl;
    while(1)
    {
    cout<<temp.val<<endl;
    if (temp.next==NULL) break;
    //accessing B node
    temp=*(temp.next);
    
    
    }
    
    
    return 0;
}
