/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<string>
#include<algorithm>
using namespace std;

int main()
{
    string s="AZYZXBDXJK";
    string str;
    for(int i=0;i<s.length();i++){
        if(s[i]>='X'){
            str.push_back(s[i]);
        }
        
    }
    //sorted using bubble sort
    for(int i=0;i<str.length()-1;i++){
        bool flag=true;
        for(int j=0;j<str.length()-1-i;j++){
            if(str[j]>str[j+1])
            swap(str[j],str[j+1]);
        }
    }
    // sort(str.begin(),str.end());
    cout<<str;

    return 0;
}