  #include <iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
for(int i=0;i<=2*n;i++){
    cout<<(char)('A'+i)<<" ";
}
cout<<endl;
int m=n-1;
 int nsp=1;
 
for(int i=1;i<=m;i++){
    for(int j=0;j<=m+1-i;j++){
        
        cout<<(char)('A'+j)<<" ";
    }
   
    for (int k=1;k<=nsp;k++){
        cout<<"  ";
    }
    nsp+=2;
    for(int j=0;j<=m+1-i;j++){
        
        cout<<(char)('A'+j)<<" ";
    }
    
    cout<<endl;
}

       
   
  
}