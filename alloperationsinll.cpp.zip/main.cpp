#include <iostream>
using namespace std;

// Creating a user-defined data type
class node {
public:
    int val;
    node* next;

    // Constructor
    node(int val) {
        this->val = val;
        this->next = NULL;
    }
};

// User-defined data structure
class LinkedList {
public:
    node* head;
    node* tail;
    int size;

    LinkedList() {
        head = tail = NULL;
        size = 0;
    }
//insertAtEnd
    void insertAtEnd(int Val) {
        node* temp = new node(Val);
        if (size == 0) {
            head = tail = temp;
        } else {
            tail->next = temp;
            tail = temp;
        }
        size++;
    }
    
    //insertAtHead
    void insertAtHead(int Val) {
        node* temp = new node(Val);
        if (size == 0) {
            head = tail = temp;
        } 
        else {
            temp->next = head;
            head=temp;
        }
        size++;
    }
    //insertAtIdx
    void insertAtIdx(int idx,int val) {
        if(idx<0||idx>size) cout<<"Invalid Index";
        else if(idx==0) insertAtHead(val);
        else if(idx==size) insertAtEnd(val);
        
        else{
        /*Traverse the list to find the node just before the insertion point i.e idx. In this case, traverse to the node at index 1 (which is 10).
        
        //traveller starts at head (88)
        //After the first loop iteration (i = 0), traveller points to 10.
        //temp->next = traveller->next (which is 20)
        
        The traveller pointer is used in the insertAtIdx function to traverse the linked list and locate the node just before the position where the new node is to be inserted.
        Increase the size of the list to 6.*/
        node* temp=new node(val);
        node* traveller=head;
        for(int i=1 ;i<idx-1;i++){
            // for temporary purpose i am keeping the value returned by traveller->next of given idx
            traveller=traveller->next;

        }
        //now i am linking the temp node with address retured by traveller->next node.
        temp->next=traveller->next;
        //now by changing the address of traveller->next with temp as temp is kept with original address of given new node.now new node is inserted by shifting node from their original idx.
        traveller->next=temp;
        size++;
        }
    }
    
    //getIndex
    int getIndex(int idx){
       if(idx<0||idx>=size){
           cout<<"Invalid Index";
           return -1;
       } 
        else if(idx==0) return head->val;
        else if(idx==size-1) return tail->val;
        else{ 
            node* temp=head;
        for(int i=1;i<size;i++){
            temp=temp->next;
            
        }
        return temp->val;
            
        }
        
    }
    //delete node at head
    void delAtHead(){
        if(size==0){
            cout<<"list is empty";
            return;
            }
        if(size==1){
        //   head=tail=NULL;
        //   size--;
            head=head->next;
            size--;
        }
        if(size>1){
            head=head->next;
            size--;
        }
    }
   //delete at End
    void delAtEnd() {
        if (size == 0) {
            cout << "List is empty" << endl;
            return;
        }
        if (size == 1) {
            delete head;
            head = tail = NULL;
            size--;
            return;
        }
        node* temp = head;
        while (temp->next != tail) {
            temp = temp->next;
        }
        delete tail;
        tail = temp;
        tail->next = NULL;
        size--;
    }
    //del at any given index
    void delAtIdx(int idx){
        if(idx<0||idx>=size){
            cout<<"Invalid Index";
            return;
        }
        else if(idx==0) return delAtHead();
        else if (idx==size-1) return delAtEnd();
        else{
            node* temp=head;
            for(int i=1;i<size-1;i++){
                temp=temp->next;
            }
            temp->next=temp->next->next;
            size--;
            
        }
    }

    // Print linked list in order
    void display() {
        node* temp = head;
        if (temp == NULL) return;
        while (temp != NULL) {
            cout << temp->val << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    LinkedList ll;
    ll.insertAtEnd(10);
    ll.insertAtEnd(20);
    ll.insertAtEnd(30);
    ll.insertAtEnd(40);
    ll.display();
    ll.insertAtHead(88);
    ll.display();
    ll.insertAtIdx(2,99);
    ll.display();
    cout<<ll.getIndex(3)<<endl;
    ll.delAtHead();
    ll.display();
    ll.delAtEnd();
    ll.display();
    ll.delAtIdx(2);
    ll.display();

    return 0;
}
