/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    string c;
    getline(cin,c);
    int x=0;
    for(int i=0;i<c.size();i++){
         x *= 10;
         //In ASCII, the character '0' has a decimal value of 48. So, if you have a character '0' and you subtract 48 from it, you get the integer 0.
        x += c[i]-48;
    }

cout<<x;
    return 0;
}