/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    //matrix A
   
    int m;
    cout<<"Enter No of Rows:";
    cin>>m;
    int n;
    cout<<"Enter No of Column:";
    cin>>n;
    
   
    
    //Matrix B
    
    int p;
    cout<<"Enter No of Rows:";
    cin>>p;
    int q;
    cout<<"Enter No of Column:";
    cin>>q;
    
    if(n==p)
    {
      int a[m][n];
       cout<<"enter elements of array A:";
      for(int i=0;i<m;i++){
          for(int j=0;j<n;j++){
              cin>>a[i][j];
          }
      }
      int  b[p][q];
        cout<<"enter elements of array B:";
      for(int i=0;i<p;i++){
          for(int j=0;j<q;j++){
              cin>>b[i][j];
          }
      }
      //resultant matrix
      int c[m][q];
       for(int i=0;i<m;i++)
       {
          for(int j=0;j<q;j++)
          {
              
              //multiply
              c[i][j]=0;
              for(int r=0;r<p;r++) //r ->3; 2*3,3*4 // r loop till row number of resultant matrix
              {
              c[i][j]+=a[i][r]*b[r][j];
              }
          }
      }
      //print c
       for(int i=0;i<m;i++)
       {
          for(int j=0;j<q;j++)
          {
              cout<<c[i][j]<<" " ;
          }
          cout<<endl;
       }
    }
    else//n!=p
    cout<<"Matrix Multiplication is not possible";
    return 0;
}
