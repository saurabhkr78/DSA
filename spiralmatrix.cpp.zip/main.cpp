/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    //matrix A
   
    int m;
    cout<<"Enter No of Rows:";
    cin>>m;
    int n;
    cout<<"Enter No of Column:";
    cin>>n;
      
      
    //input  
    int a[m][n];
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cin>>a[i][j];
        }
    }
    cout<<endl;
   //print
    for(int i=0;i<m;i++)
    {
        if(i%2==0){
        for(int j=0;j<n;j++){
            cout<<a[i][j]<<" ";
        }
        
        }
        else
        for(int j=n-1;j>=0;j--){
            cout<<a[i][j]<<" ";
        }
        cout<<endl;
    }
 
 
    return 0;
}
