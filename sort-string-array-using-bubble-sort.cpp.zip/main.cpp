#include <iostream>
#include <string>

using namespace std;

int main() {
    string arr[] = {"himanshu","Hitanshu","yashika", "ronak", "saurabh", "chitransh", "nandini"};
    int n = 6;

    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }

    bool swapped;

    for (int i = 0; i < n - 1; i++) {
        swapped = false;

        for (int j = 0; j < n - 1 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                swapped = true;
            }
        }

        if (!swapped) {
            break;
        }
    }

    cout << "\nSorted array: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }

    return 0;
}