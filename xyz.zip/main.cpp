#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int minimumTicketNeeded(int n, vector<int>& a) {
    vector<pair<int, int>> indexedArray;  // To store {element, original index} pairs

    for (int i = 0; i < n; i++) {
        indexedArray.push_back({a[i], i});
    }

    // Sort in descending order based on elements
    sort(indexedArray.begin(), indexedArray.end(), greater<pair<int, int>>());

    int reorderCount = 0;

    for (int i = 0; i < n; i++) {
        // Check if the element is not in its correct position
        if (indexedArray[i].second != i) {
            reorderCount++;
        }
    }

    return reorderCount;
}

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n, m;
        cin >> n >> m;

        vector<int> a(n);
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }

        int result = minimumTicketNeeded(n, a);
        cout << result << endl;
    }

    return 0;
}
